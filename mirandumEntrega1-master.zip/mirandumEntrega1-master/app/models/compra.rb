class Compra < ApplicationRecord
	belongs_to :user
end
