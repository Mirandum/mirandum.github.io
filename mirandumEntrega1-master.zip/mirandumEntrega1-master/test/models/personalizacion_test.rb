require 'test_helper'

class PersonalizacionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
