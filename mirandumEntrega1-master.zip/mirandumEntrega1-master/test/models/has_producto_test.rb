require 'test_helper'

class HasProductoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
